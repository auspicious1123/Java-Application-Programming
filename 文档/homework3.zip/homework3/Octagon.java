

/**
 * @author-Rui Wang rw1
 */
public class Octagon extends Shape {
    
    private double side;

    /**
     * @param newSide side of octagon
     */
    public Octagon(double newSide) {
        // TODO Auto-generated constructor stub
        super(2 * (1 + Math.sqrt(2) * newSide * newSide), 8 * newSide);
        side = newSide;
    }
    
    /**
     * Returns side of square object.
     * @return side value of square object
     */
    public double getSide() {
        return side;
    }

    /**
     * Returns string representation of shape object.
     * @return a string representation of shape object
     */
    public String toString() {
        return "Octagon " + String.format("%.3f", getArea()) + " " + String.format("%.3f", getPerimeter());
    }

}
