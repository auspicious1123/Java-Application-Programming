

/**
 * @author-Rui Wang rw1
 */
public class Hexagon extends Shape {
    
    private double side;
    //public int n = 2;

    /**
     * 
     */
    public Hexagon(double newSide) {
        super(1.5 * Math.sqrt(3) * newSide * newSide, 6 * newSide);   // super is eara
        side = newSide;
    }
    
    /**
     * Returns side of square object.
     * @return side value of square object
     */
    public double getSide() {
        return side;
    }

    /**
     * Returns string representation of shape object.
     * @return a string representation of shape object
     */
    public String toString() {
        return "Hexagon " + String.format("%.3f", getArea()) + " " + String.format("%.3f", getPerimeter());
    }

}
